package org.example.utilidades;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {


    public static Boolean buscarCoincidencia(String expresionRegular, String cadena){
        Pattern patron = Pattern.compile(expresionRegular);
        Matcher emparejador = patron.matcher(cadena);
        if (emparejador.matches()) {
            return true;
        } else {
            return false;
        }
    }


    public static LocalDate formatearFechaStringLocalDate (String fecha, String formato){
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern(formato);
        return LocalDate.parse(fecha, formatoFecha);
    }



    public enum Mensajes {

        NOMBRE_SOLO_LETRAS ("Señor usuario, solo se recibe letras"),
        NOMBRE_MUY_CORTO ("El nombre es demasiado corto"),
        CORREO_INVALIDO ("El correo ingresado no es valido"),
        CARACTERES_EMPRESA ("El nombre de la empresa no puede sobrepasar los 30 caracteres"),
        NUMEROS_ENTEROS ("Se permiten numero enteros en este campo"),
        NIT_MUY_CORTO ("El numero de nit debe ser mayor a diez digitos"),
        ZONA_INVALIDA  ("La zona no es valida, debe ser del 1 al 4");

        CARACTERES_OFERTA ("El numero de caracteres para la oferta debe ser menor a 20"),
        COHERENCIA_FECHAS ("La fecha de inicio no puede ser mayor a la fecha de fin "),
        CANTIDAD_PERSONAS ("La cantidad de personas por reserva debe ser menor a 4 personas"),
        VALOR_COSTO ("El valor del costo por persona no puede ser negativo"),
        Mensajes("Este formato de fecha no es valido"),

        private String mensaje;

        Mensajes (String mensaje){
            this.mensaje = mensaje;
        }

        public String getMensaje() {
            return mensaje;
        }
    }


    }
